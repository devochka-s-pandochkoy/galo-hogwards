<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package galo-hogwards
 */

?>

	<footer id="colophon" class="site-footer">
		<div class="site-info">
			©
			<?php echo esc_html( date( 'Y' ) ); ?> <!-- Текущий год -->

			<a href="<?php echo esc_url( __( 'https://%D0%B3%D0%BE%D1%81%D0%B0%D1%80%D1%85%D0%B8%D0%B248.%D1%80%D1%84/', 'galo-hogwards' ) ); ?>" target="_blank">
				<?php
					printf( esc_html__( 'ОКУ "Государственный архив Липецкой области"', 'galo-hogwards' ), 'WordPress' );
				?>
			</a>
				
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
